# Redlife
A Secretaria Nacional de Saúde Pública propõe um Sistema Nacional de Doação de Sangue para integrar hemocentros, facilitar a busca por doadores e otimizar estoques. O objetivo é centralizar dados, melhorar a comunicação e tornar o processo de doação e transfusão mais ágil, seguro e eficiente em todo o país.
